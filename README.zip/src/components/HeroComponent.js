import React, { Component } from 'react'
class HeroSection extends Component {
    render() {
        return (
            <div className="hero-container" data-aos="fade-in">
        <h1>Akshay Sawant</h1>
        <p>I'm <span className="typed" data-typed-items="Developer, Team Player, Quick Learner, Passionate" /></p>
      </div>
        )
    }
}
export default HeroSection