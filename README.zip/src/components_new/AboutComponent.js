import React, { Component } from 'react'
class AboutSection extends Component {
    render() {
        return (
            <section className="resume-section" id="about">
        <div className="resume-section-content">
          <h1 className="mb-0">
            Akshay 
            <span className="text-primary">Sawant</span>
          </h1>
          <div className="subheading mb-5">
            <a href="mailto:name@email.com">akshay.sawant@gmail.com</a>
          </div>
          <p className="lead mb-5">I am experienced senior backend developer,quick leaner, ability to collaborate with teams and work as an individual too. Excellect team player with great communication skills.</p>
          <div className="social-icons">
            <a className="social-icon" href="/#"><i className="fab fa-linkedin-in" /></a>
            <a className="social-icon" href="/#"><i className="fab fa-github" /></a>
            <a className="social-icon" href="/#"><i className="fab fa-twitter" /></a>
            <a className="social-icon" href="/#"><i className="fab fa-facebook-f" /></a>
          </div>
        </div>
      </section>
        )
    }

}
export default AboutSection