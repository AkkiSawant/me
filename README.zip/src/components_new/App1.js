import './App.css';
import AboutSection from './components/AboutComponent';
import EducationSection from './components/EducationComponent';
import ExperienceSection from './components/ExperienceComponent';
import NavSection from './components/NavComponent';
import SkillSection from './components/SkillsComponent';

function App() {
    return (
      <div>
      <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top" id="sideNav">
        <NavSection></NavSection>
      </nav>  
      <div class="container-fluid p-0">
        <AboutSection></AboutSection>
      </div>
      <hr class="m-0" />
      <section class="resume-section" id="experience">
        <ExperienceSection></ExperienceSection>
      </section>
      <hr class="m-0" />
      <section class="resume-section" id="education">
        <EducationSection></EducationSection>
      </section>
      <hr class="m-0" />
      <section class="resume-section" id="skills">
        <SkillSection></SkillSection>
      </section>
      </div>
    );
}

export default App;
